
# promptsynth_app.py (v1.5: Sequencer Grid + Mixer + AI Prompt Extension)

import streamlit as st
import numpy as np
import scipy.io.wavfile as wav
import matplotlib.pyplot as plt
import os
import uuid
import json
from pathlib import Path
from io import BytesIO
from zipfile import ZipFile
import time
import random

# ========== 🎚️ Global Settings ==========
st.sidebar.header("🎚️ Global Settings")
BPM = st.sidebar.slider("Tempo (BPM)", 60, 180, 120)
SECONDS_PER_STEP = 60 / BPM / 2
GLOBAL_VOLUME = st.sidebar.slider("Global Volume", 0.0, 2.0, 1.0)
GLOBAL_FX = st.sidebar.multiselect("Global FX", ["distortion", "reverb"], default=[])

# ========== 🎨 Style Presets ==========
STYLE_PRESETS = {
    "Lofi": "warm soft sub bass with reverb",
    "Techno": "punchy loud kick with distortion",
    "Glitch": "short distorted clap",
    "Ambient": "long pad with reverb",
    "Dubstep": "heavy sub bass with distortion"
}
selected_style = st.sidebar.selectbox("🎨 Style Preset", ["None"] + list(STYLE_PRESETS.keys()))
if selected_style != "None":
    st.session_state["preset_prompt"] = STYLE_PRESETS[selected_style]
else:
    st.session_state["preset_prompt"] = ""

# ========== 🔧 Instrument Generator Placeholders ==========
def generate_riser(params):
    t = np.linspace(0, params['duration'], int(44100 * params['duration']))
    freq = np.linspace(params['pitch'], params['pitch'] * 3, t.shape[0])
    waveform = np.sin(2 * np.pi * freq * t)
    return apply_fx(waveform * params['volume'], params)

def generate_kick(params):
    t = np.linspace(0, params['duration'], int(44100 * params['duration']))
    freq = np.linspace(params['pitch'] * 2, params['pitch'], t.shape[0])
    waveform = np.sin(2 * np.pi * freq * t)
    envelope = np.exp(-t * 10)
    return apply_fx(waveform * envelope * params['volume'], params)

def generate_clap(params):
    t = np.linspace(0, params['duration'], int(44100 * params['duration']))
    noise = np.random.randn(len(t))
    envelope = np.exp(-t * 25)
    return apply_fx(noise * envelope * params['volume'], params)

def generate_sub_bass(params):
    t = np.linspace(0, params['duration'], int(44100 * params['duration']))
    waveform = np.sin(2 * np.pi * params['pitch'] * t)
    return apply_fx(waveform * params['volume'], params)

def generate_pad(params):
    t = np.linspace(0, params['duration'], int(44100 * params['duration']))
    waveform = np.sin(2 * np.pi * params['pitch'] * t)
    envelope = np.sin(np.pi * t / params['duration'])
    return apply_fx(waveform * envelope * params['volume'], params)

# ========== 🧪 FX Engine ==========
def apply_fx(waveform, params):
    if "distortion" in params.get("fx", []) + GLOBAL_FX:
        waveform = np.tanh(waveform * 5)
    if "reverb" in params.get("fx", []) + GLOBAL_FX:
        echo = np.pad(waveform, (5000, 0), mode='constant')[:-5000] * 0.3
        waveform = waveform + echo
    pan = params.get("pan", 0.5)
    volume = params.get("volume", 1.0) * GLOBAL_VOLUME
    left = waveform * (1 - pan) * volume
    right = waveform * pan * volume
    return np.vstack([left, right])

# ========== 🎛️ Instrument Registry ==========
INSTRUMENT_GENERATORS = {
    "riser": generate_riser,
    "kick": generate_kick,
    "clap": generate_clap,
    "sub_bass": generate_sub_bass,
    "pad": generate_pad,
}

# ========== 🧠 Prompt Parser ==========
def parse_prompt(prompt):
    prompt = prompt.lower()
    instrument = "riser"
    duration = 1.5
    pitch = 220
    volume = 0.8
    pan = 0.5
    fx = []

    if "kick" in prompt: instrument = "kick"
    elif "clap" in prompt: instrument = "clap"
    elif "sub" in prompt or "bass" in prompt: instrument = "sub_bass"
    elif "pad" in prompt: instrument = "pad"

    if "short" in prompt: duration = 0.25
    if "long" in prompt or "ambient" in prompt: duration = 3.0
    if "high" in prompt: pitch = 880
    if "low" in prompt: pitch = 60
    if "loud" in prompt: volume = 1.0
    if "quiet" in prompt: volume = 0.3
    if "left" in prompt: pan = 0.0
    if "right" in prompt: pan = 1.0
    if "center" in prompt: pan = 0.5
    if "distort" in prompt or "distortion" in prompt: fx.append("distortion")
    if "reverb" in prompt: fx.append("reverb")

    return {
        "instrument": instrument,
        "duration": duration,
        "pitch": pitch,
        "volume": volume,
        "fx": fx,
        "pan": pan,
    }

# ========== 🔁 Remix Prompt Variation ==========
def remix_prompt(prompt):
    mods = ["high", "low", "loud", "quiet", "left", "right", "center", "distortion", "reverb"]
    base = prompt.split()
    base += random.sample(mods, k=2)
    return " ".join(base)

# ========== 🚀 Streamlit UI ==========
st.set_page_config(layout="wide")
st.title("🎛️ PromptSynth v1.5: Grid + Mixer + AI")

prompt = st.text_input("🎤 Describe a sound:", st.session_state.get("preset_prompt", "short distorted kick"))

if st.button("🔄 Remix This Loop"):
    prompt = remix_prompt(prompt)
    st.experimental_rerun()
